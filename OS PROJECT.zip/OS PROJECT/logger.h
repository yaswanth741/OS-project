#ifndef LOGGER_H
#define LOGGER_H

void log_action(const char *action);

#endif
