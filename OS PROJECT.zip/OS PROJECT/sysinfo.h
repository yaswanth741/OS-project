#ifndef SYSINFO_H
#define SYSINFO_H

void get_process_id();
void get_system_time();
void get_os_info();

#endif
