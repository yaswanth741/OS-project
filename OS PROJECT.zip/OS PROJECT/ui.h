#ifndef UI_H
#define UI_H

void clear_screen();
void header(const char *title);

#endif
