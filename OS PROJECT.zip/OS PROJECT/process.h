#ifndef PROCESS_H
#define PROCESS_H

void create_process();

#endif
