#ifndef LOGIN_H
#define LOGIN_H

int authenticate();

#endif
